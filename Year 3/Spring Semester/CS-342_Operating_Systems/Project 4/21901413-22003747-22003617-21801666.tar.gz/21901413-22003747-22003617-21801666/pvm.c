#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define PAGE_SIZE 0x1000
#define MAX_LINE_LENGTH 1000

void print_frame_info(unsigned long flags, unsigned long count) {
    const char *flag_names[] = {
            "LOCKED", "ERROR", "REFERENCED", "UPTODATE", "DIRTY", "LRU", "ACTIVE",
            "SLAB", "WRITEBACK", "RECLAIM", "BUDDY", "MMAP", "ANON", "SWAPCACHE",
            "SWAPBACKED", "COMPOUND_HEAD", "COMPOUND_TAIL", "HUGE", "UNEVICTABLE",
            "HWPOISON", "NOPAGE", "KSM", "THP", "BALLOON", "ZERO_PAGE", "IDLE"
    };

    printf("Flags:\n");
    for (int i = 0; i < 26; i++) {
        unsigned long bit = (flags >> i) & 1;
        printf("%02d. %-15s%lu\n", i, flag_names[i], bit);
    }

    printf("\nMapping count: %lu\n", count);
}


// Tüm bitleri tek tek okuyabilmen için kontrol için lazım olacak sonra 55 ve 5. bitler arasını doğru almış mıyım gibi şeyler için
void printBits(unsigned long num) {
    for (int i = sizeof(unsigned long) * 8 - 1; i >= 0; i--) {
        unsigned long mask = 1UL << i;
        unsigned long bit = (num & mask) ? 1 : 0;
        printf("%lu", bit);
    }
    printf("\n");
}

unsigned long
getNumOfUsedTablesBetweenVPNs(unsigned long startVPN, unsigned long endVPN, int shiftOffset,
                              unsigned long previousEndVPN) {
    unsigned long counter2;
    unsigned long secondTableStartIndex = (startVPN >> shiftOffset);
    unsigned long secondTableEndIndex = (endVPN >> shiftOffset);
    counter2 = secondTableEndIndex - secondTableStartIndex + 1;

    if (previousEndVPN) {
        unsigned long previousEndIndex = (previousEndVPN >> shiftOffset);
        if (previousEndIndex == secondTableStartIndex) {
            counter2 -= 1;
        }
    }

    return counter2;
}

FILE *openMaps(int id) {
    FILE *file;
    // Find file path with given pid
    char filePath[40];
    snprintf(filePath, sizeof(filePath), "/proc/%d/maps", id);

    // Open the file
    file = fopen(filePath, "r");
    if (file == NULL) {
        printf("can not open file: /proc/%d/maps\n", id);
    }
    return file;
}

int openPageMaps(int id) {
    // Find file path with given pid
    char filePath[40];
    snprintf(filePath, sizeof(filePath), "/proc/%d/pagemap", id);

    // Open the file
    return open(filePath, O_RDONLY);
}


void printMappingBetweenVAs(const char *startAddress, const char *endAddress,
                            int pageMapFile, int info) {
    unsigned long entry, offset, startVPN, endVPN, currentVPN;

    // Convert startAddress and endAddress to startVA and endVA
    startVPN = strtoul(startAddress, NULL, 16) / PAGE_SIZE;
    endVPN = strtoul(endAddress, NULL, 16) / PAGE_SIZE;

    offset = sizeof(unsigned long) * (startVPN);
    currentVPN = startVPN;
    for (int i = 0; i < endVPN - startVPN; ++i) {
        lseek(pageMapFile, offset, SEEK_SET);
        read(pageMapFile, &entry, sizeof(unsigned long));

        unsigned long bit64 = (entry >> 63) & 1; // Get the 63rd bit

        if (info == 1) {
            printf("mapping: vpn=0x%lx ", currentVPN);
            if (bit64 == 1) {
                unsigned long pfn = (entry) & ((1UL << 55) - 1); // Get the first 55 bits
                printf("pfn=0x%lx\n", pfn);
            } else {
                printf("not-in-memory\n");
            }
        } else if (info == 2) {
            if (bit64 == 1) {
                printf("mapping: vpn=0x%lx ", currentVPN);
                unsigned long pfn = entry & ((1UL << 55) - 1); // Get the first 55 bits
                printf("pfn=0x%lx\n", pfn);
            }
        }

        offset += sizeof(unsigned long);
        currentVPN += 1;
    }
}

int main(int argc, char *argv[]) {

    if (argc < 2) {
        printf("Few arguments are specified\n");
        return 1;
    }

    if (strcmp(argv[1], "-mapva") == 0) {
        unsigned long entry, offset, va, vpn;

        int id = atoi(argv[2]);  // Get id from the third argument (PID)

        char *vaStr = argv[3];

        // Check if the VA value is specified in hexadecimal
        if (strncmp(vaStr, "0x", 2) == 0) {
            va = strtoul(vaStr, NULL, 16);  // Get VA from the fourth argument (hexadecimal)
        } else {
            va = strtoul(vaStr, NULL, 10);  // Get VA from the fourth argument (decimal)
        }

        int fd = openPageMaps(id);
        vpn = va / PAGE_SIZE;
        offset = sizeof(unsigned long) * (vpn);
        lseek(fd, offset, SEEK_SET);
        read(fd, &entry, sizeof(unsigned long));

        unsigned long bit64 = (entry >> 63) & 1; // Get the 63rd bit

        printf("[va=0x%lx000, ", va);
        if (bit64 == 1) {
            unsigned long bits55 = entry & ((1UL << 55) - 1); // Get the first 55 bits
            // Print exactly 16 hexadecimal digits (64 bits)
            printf("pa=0x%013lx000]\n", bits55);
        } else {
            printf("not-in-memory]\n");
        }
    } else if (strcmp(argv[1], "-frameinfo") == 0) {
        unsigned long entry, offset, pfn;
        char *pfnStr = argv[2];

        // Check if the VA value is specified in hexadecimal
        if (strncmp(pfnStr, "0x", 2) == 0) {
            pfn = strtoul(pfnStr, NULL, 16);  // Get VA from the fourth argument (hexadecimal)
        } else {
            pfn = strtoul(pfnStr, NULL, 10);  // Get VA from the fourth argument (decimal)
        }

        int pageFlagFile = open("/proc/kpageflags", O_RDONLY);
        int pageCountFile = open("/proc/kpagecount", O_RDONLY);
        unsigned long mapCount = 0;

        offset = sizeof(unsigned long) * (pfn);
        lseek(pageCountFile, offset, SEEK_SET);
        read(pageCountFile, &mapCount, sizeof(unsigned long));

        offset = sizeof(unsigned long) * (pfn);
        lseek(pageFlagFile, offset, SEEK_SET);
        read(pageFlagFile, &entry, sizeof(unsigned long));

        print_frame_info(entry, mapCount);
    } else if (strcmp(argv[1], "-pte") == 0) {
        unsigned long entry, offset, va, vpn;

        int id = atoi(argv[2]);  // Get id from the third argument (PID)

        char *vaStr = argv[3];

        // Check if the VA value is specified in hexadecimal
        if (strncmp(vaStr, "0x", 2) == 0) {
            va = strtoul(vaStr, NULL, 16);  // Get VA from the fourth argument (hexadecimal)
        } else {
            va = strtoul(vaStr, NULL, 10);  // Get VA from the fourth argument (decimal)
        }

        int fd = openPageMaps(id);
        vpn = va / PAGE_SIZE;
        offset = sizeof(unsigned long) * (vpn);
        lseek(fd, offset, SEEK_SET);
        read(fd, &entry, sizeof(unsigned long));

        printf("[vaddr=0x%lx, vpn=0x%lx]: ", va, vpn);

        unsigned long bit64 = (entry >> 63) & 1; // Get the 63rd bit
        printf("present=%lx", bit64);

        unsigned long bit = (entry >> 62) & 1; // Get the 62nd bit
        printf(", swapped=%lx", bit);

        bit = (entry >> 61) & 1; // Get the 61st bit
        printf(", file-anon=%lx", bit);

        bit = (entry >> 56) & 1; // Get the 56th bit
        printf(", exclusive=%lx", bit);

        bit = (entry >> 55) & 1; // Get the 55th bit
        printf(", softdirty=%lx", bit);

        if (bit64 == 1) {
            unsigned long bits55 = entry & ((1UL << 55) - 1); // Get the first 55 bits
            printf(", pfn=0x%013lx\n", bits55);
        } else {
            unsigned long swapBits = entry & ((1UL << 5) - 1); // Get the first 5 bits
            printf(", swap Type=0x%lx\n", swapBits);

            swapBits = (entry >> 5) & ((1UL << 51) - 1); // Get the bits between 55th and 5th
            printf(", swap Offset=0x%lx\n", swapBits);
        }
    } else if (strcmp(argv[1], "-memused") == 0) {
        int id = atoi(argv[2]);  // Get id from the third argument (PID)
        unsigned long entry;
        FILE *file;
        char line[MAX_LINE_LENGTH];
        unsigned long startVPN;
        unsigned long endVPN;
        unsigned long offset;
        char *startAddress;
        char *endAddress;
        unsigned long vmCounter = 0;
        unsigned long pmCounter = 0;
        unsigned long pmOnlyCounter = 0;

        // Open the file
        file = openMaps(id);
        if (file == NULL) {
            printf("Failed to open the file.\n");
            return 1;
        }

        int pageCountFile = open("/proc/kpagecount", O_RDONLY);


        int pageMapFile = openPageMaps(id);


        // Read the file line by line using fgets
        while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
            // Split the line by spaces
            startAddress = strtok(line, "-");
            endAddress = strtok(NULL, " ");

            // Convert startAddress and endAddress to startVA and endVA
            startVPN = strtoul(startAddress, NULL, 16) / PAGE_SIZE;
            endVPN = strtoul(endAddress, NULL, 16) / PAGE_SIZE;

            offset = sizeof(unsigned long) * (startVPN);
            for (int i = 0; i < endVPN - startVPN; ++i) {
                lseek(pageMapFile, offset, SEEK_SET);
                read(pageMapFile, &entry, sizeof(unsigned long));

                unsigned long bit63 = (entry >> 63) & 1; // Get the 63rd bit

                if (entry) {
                    if (bit63 == 1) {
                        unsigned long pfn = entry & ((1UL << 55) - 1); // Get the first 55 bits
                        lseek(pageCountFile, pfn * sizeof(unsigned long), SEEK_SET);
                        read(pageCountFile, &entry, sizeof(unsigned long));

                        if (entry > 0) {
                            pmCounter += 1;
                            if (entry == 1) {
                                pmOnlyCounter += 1;
                            }
                        }
                    }
                }
                offset += sizeof(unsigned long);
            }
            vmCounter += endVPN - startVPN;
        }


        printf("(pid=%d) memused: virtual=%lu KB, pmem_all=%lu KB, pmem_alone=%lu KB, mappedonce=%lu KB\n", id,
               vmCounter * 4, pmCounter * 4, pmOnlyCounter * 4, pmOnlyCounter * 4);

        // Close the file
        fclose(file);
    } else if (strcmp(argv[1], "-maprange") == 0) {
        unsigned long entry, offset, vaStart, vaEnd;

        int id = atoi(argv[2]);  // Get id from the third argument (PID)

        char *vaStr = argv[3];

        // Check if the VA value is specified in hexadecimal
        if (strncmp(vaStr, "0x", 2) == 0) {
            vaStart = strtoul(vaStr, NULL, 16);  // Get VA from the fourth argument (hexadecimal)
        } else {
            vaStart = strtoul(vaStr, NULL, 10);  // Get VA from the fourth argument (decimal)
        }

        vaStr = argv[4];

        // Check if the VA value is specified in hexadecimal
        if (strncmp(vaStr, "0x", 2) == 0) {
            vaEnd = strtoul(vaStr, NULL, 16);  // Get VA from the fourth argument (hexadecimal)
        } else {
            vaEnd = strtoul(vaStr, NULL, 10);  // Get VA from the fourth argument (decimal)
        }


        unsigned long startVPN;
        unsigned long endVPN;
        unsigned long currentVpn;


        // Find file path with given pid
        int pageMapFile = openPageMaps(id);

        // Convert startAddress and endAddress to startVA and endVA
        startVPN = vaStart / PAGE_SIZE;
        endVPN = vaEnd / PAGE_SIZE;
        currentVpn = startVPN;

        offset = sizeof(unsigned long) * (currentVpn);
        while (currentVpn < endVPN) {
            lseek(pageMapFile, offset, SEEK_SET);
            read(pageMapFile, &entry, sizeof(unsigned long));

            unsigned long bit64 = (entry >> 63) & 1; // Get the 63rd bit

            printf("mapping: vpn=0x%lx ", currentVpn);

            if (entry == 0) {
                printf("unused\n");
            } else if (bit64 == 1) {
                unsigned long pfn = entry & ((1UL << 55) - 1); // Get the first 55 bits

                printf("pfn=0x%lx\n", pfn);
            } else {
                printf("not-in-memory\n");
            }

            offset += sizeof(unsigned long);
            currentVpn += 1;
        }
    } else if (strcmp(argv[1], "-mapall") == 0) {
        FILE *file;
        char line[MAX_LINE_LENGTH];
        char *startAddress;
        char *endAddress;
        int id = atoi(argv[2]);  // Get id from the third argument (PID)

        file = openMaps(id);

        int pageMapFile = openPageMaps(id);


        // Read the file line by line using fgets
        while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
            // Split the line by spaces
            startAddress = strtok(line, "-");
            endAddress = strtok(NULL, " ");
            printMappingBetweenVAs(startAddress, endAddress, pageMapFile, 1);
        }

        // Close the file
        fclose(file);
    } else if (strcmp(argv[1], "-mapallin") == 0) {
        FILE *file;
        char line[MAX_LINE_LENGTH];
        char *startAddress;
        char *endAddress;
        int id = atoi(argv[2]);  // Get id from the third argument (PID)

        file = openMaps(id);

        int pageMapFile = openPageMaps(id);


        // Read the file line by line using fgets
        while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
            // Split the line by spaces
            startAddress = strtok(line, "-");
            endAddress = strtok(NULL, " ");
            printMappingBetweenVAs(startAddress, endAddress, pageMapFile, 2);
        }

        // Close the file
        fclose(file);
    } else if (strcmp(argv[1], "-alltablesize") == 0) {
        int id = atoi(argv[2]);  // Get id from the third argument (PID)
        FILE *file;
        char line[MAX_LINE_LENGTH];

        unsigned long startVPN;
        unsigned long endVPN;

        char *startAddress;
        char *endAddress;

        unsigned long secondTableCounter = 0;
        unsigned long thirdTableCounter = 0;
        unsigned long fourthTableCounter = 0;
        file = openMaps(id);

        if (!file) {
            return 1;
        }

        unsigned long previousEndVPN = 0;
        // Read the file line by line using fgets
        while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
            // Split the line by spaces
            startAddress = strtok(line, "-");
            endAddress = strtok(NULL, " ");

            // Convert startAddress and endAddress to startVA and endVA
            startVPN = strtoul(startAddress, NULL, 16) / PAGE_SIZE;
            endVPN = strtoul(endAddress, NULL, 16) / PAGE_SIZE - 1;

            secondTableCounter += getNumOfUsedTablesBetweenVPNs(startVPN, endVPN, 27, previousEndVPN);
            thirdTableCounter += getNumOfUsedTablesBetweenVPNs(startVPN, endVPN, 18, previousEndVPN);
            fourthTableCounter += getNumOfUsedTablesBetweenVPNs(startVPN, endVPN, 9, previousEndVPN);

            previousEndVPN = endVPN;
        }

        unsigned long totalFrames = 1 + secondTableCounter + thirdTableCounter + fourthTableCounter;
        printf("(pid=%d) total memory occupied by 4-level page table: %lu KB (%lu frames)\n", id, totalFrames * 4,
               totalFrames);
        printf("(pid=%d) number of page tables used: level1=1, level2=%lu, level3=%lu, level4=%lu\n", id,
               secondTableCounter, thirdTableCounter, fourthTableCounter);

        // Close the file
        fclose(file);
    }
    return 0;
}