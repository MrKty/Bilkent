Ömer Oktay Gültekin 21901413 Section 1
Mert Ünlü 22003747 Section 3
Barış Tan Ünal 22003617 Section 3
Gökberk Keskinkılıç 21801666 Section 3
