Ömer Oktay Gültekin 21901413 Section 1
Muhammed İkbal Doğan 21701990 Section 1