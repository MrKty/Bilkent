#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>
#include "rm.h"

// global variables
int DA;  // indicates if deadlocks will be avoided or not
int N;   // number of processes
int M;   // number of resource types
int ExistingRes[MAXR]; // Existing resources vector
pthread_t ThreadIds[MAXP]; // Thread alive status array
int MaxDemand[MAXP][MAXR]; // Maximum resource demand matrix
int Available[MAXR]; // Available resources vector
int Allocation[MAXP][MAXR]; // Allocated resources matrix
int Need[MAXP][MAXR]; // Needed resources matrix
int Request[MAXP][MAXR]; // Requested resources matrix

pthread_mutex_t mutex;
pthread_cond_t condition;
// end of global variables

void allocateResources(int tid, const int request[]) {
    for (int i = 0; i < M; ++i) {
        Allocation[tid][i] += request[i];
        Available[i] -= request[i];

        if (DA != 0) {
            Need[tid][i] -= request[i];
        }
    }
}

void releaseResources(int tid, const int release[], int option) {
    for (int i = 0; i < M; ++i) {
        Available[i] += release[i];
        Allocation[tid][i] -= release[i];

        if (option == 1 && DA != 0){
            Need[tid][i] += release[i];
        }
    }
}

int isSafe(int tid, int request[]) {
    allocateResources(tid, request);
    int Work[M]; // Temporary vector representing the available pool of resources
    int Finish[N]; // Finish status array

    // Step 1: Initialization
    for (int i = 0; i < M; ++i) {
        Work[i] = Available[i];
    }

    for (int i = 0; i < N; i++) {
        Finish[i] = 0;
    }

    // Step 2: Find an i such that Finish[i] = false and Need[i] <= Work
    int found = 1;
    while (found) {
        found = 0;
        for (int i = 0; i < N; ++i) {
            if (!Finish[i]) {
                int canFinish = 1;
                for (int j = 0; j < M; ++j) {
                    if (Need[i][j] > Work[j]) {
                        canFinish = 0;
                        break;
                    }
                }

                if (canFinish) {
                    // Step 3: Update Work and Finish
                    for (int j = 0; j < M; ++j) {
                        Work[j] += Allocation[i][j];
                    }
                    Finish[i] = 1;
                    found = 1;
                }
            }
        }
    }

    releaseResources(tid, request, 1);

    // Step 4: Check if Finish[i] is true for all i
    for (int i = 0; i < N; ++i) {
        if (!Finish[i]) {
            // System state is unsafe
            return 0;
        }
    }

    // System state is safe
    return 1;
}

int resourcesAvailable(const int request[]) {
    for (int i = 0; i < M; ++i) {
        if (Available[i] < request[i]) {
            pthread_mutex_unlock(&mutex);
            return 0;
        }
    }
    return 1;
}

int isThreadStarted() {
    pthread_t tid = pthread_self();
    int i = -1;
    for (int j = 0; j < MAXP; ++j) {
        if (ThreadIds[j] == tid) {
            i = j;
        }
    }
    if (i == -1) {
        //printf("Thread %lu has not started yet.\n", tid);
    }
    return i;
}

int rm_thread_started(int tid) {
    // Check if the tid is within the range of valid threads
    if (tid < 0 || tid >= N)
        return -1;

    // Set the thread alive status for the given tid to indicate it has started
    ThreadIds[tid] = pthread_self();

    return 0;
}


int rm_thread_ended() {
    // Check if the thread has started
    int i = isThreadStarted();

    if (i == -1) {
        return -1;
    }

    // Mark the thread as ended
    ThreadIds[i] = 0;

    return 0;
}


int rm_claim(int claim[]) {
    // Check if deadlock avoidance is enabled
    if (DA == 0) {
        //printf("Deadlock avoidance is not enabled.\n");
        return -1;
    }

    // Check if the thread has started
    int tid = isThreadStarted();
    if (tid == -1) {
        return -1;
    }

    // Check if the claimed resources exceed the existing resources
    for (int i = 0; i < M; i++) {
        if (claim[i] > ExistingRes[i]) {
            //printf("Thread %d is trying to claim more instances of resource %d than existing.\n", tid, i);
            return -1;
        }
    }

    // Update the maximum demand matrix with the claim information
    for (int i = 0; i < M; i++) {
        if (DA == 0) {
            MaxDemand[tid][i] = 0;
            Need[tid][i] = 0;
        } else {
            MaxDemand[tid][i] = claim[i];
            Need[tid][i] = claim[i];
        }
        Request[tid][i] = 0;
        Allocation[tid][i] = 0;
    }

    return 0;
}


int rm_init(int p_count, int r_count, int r_exist[], int avoid) {
    if (p_count <= 0 || r_count <= 0 || p_count > MAXP || r_count > MAXR) {
        // Invalid input parameters
        return -1;
    }

    DA = avoid;
    N = p_count;
    M = r_count;

    // initialize (create) resources
    for (int i = 0; i < M; ++i) {
        ExistingRes[i] = r_exist[i];
        Available[i] = ExistingRes[i];
    }
    // resources initialized (created)

    // Initialize the mutex and condition variable
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&condition, NULL);

    return 0;
}


int rm_request(int request[]) {

    pthread_mutex_lock(&mutex);

    // Check if the thread has started
    int tid = isThreadStarted();
    if (tid == -1) {
        pthread_mutex_unlock(&mutex);
        return -1;
    }

    for (int i = 0; i < M; ++i) {
        Request[tid][i] += request[i];
    }

    // Check if the requested resources exceed the existing resources
    for (int i = 0; i < M; ++i) {
        if (request[i] > ExistingRes[i]) {
            //printf("Thread %d requested more instances of resource type %d than available.\n", tid, i);
            pthread_mutex_unlock(&mutex);
            return -1;
        }
    }

    // Check if the requested resources are available
    while (!resourcesAvailable(request)) {
        pthread_cond_wait(&condition, &mutex);
    }

    // Check if deadlock avoidance is enabled
    if (DA) {
        // Check if the request can be granted without causing a deadlock
        while (!isSafe(tid, request)) {
            pthread_cond_wait(&condition, &mutex);
        }
    }


    // Allocate the requested resources
    allocateResources(tid, request);


    for (int i = 0; i < M; ++i) {
        Request[tid][i] -= request[i];
    }

    pthread_mutex_unlock(&mutex);
    return 0;
}

int rm_release(int release[]) {
    pthread_mutex_lock(&mutex);
    // Check if the thread has started
    int tid = isThreadStarted();
    if (tid == -1) {
        pthread_mutex_unlock(&mutex);
        return -1;
    }

    // Check if the thread has allocated the resources to release
    for (int i = 0; i < M; ++i) {
        if (release[i] > Allocation[tid][i]) {
            //printf("Thread %d is trying to release more instances of resource type %d than allocated.\n", tid, i);
            pthread_mutex_unlock(&mutex);
            return -1;
        }
    }

    // Release the indicated resource instances
    releaseResources(tid, release, 0);

    // Wake up blocked threads waiting in rm_request()
    pthread_cond_broadcast(&condition);

    pthread_mutex_unlock(&mutex);

    return 0;
}


int rm_detection() {
    pthread_mutex_lock(&mutex);

    int Work[M];   // Available resources vector
    int Finish[N]; // Finish status array

    // Step 1: Initialization
    for (int i = 0; i < M; ++i) {
        Work[i] = Available[i];
    }

    for (int i = 0; i < N; ++i) {
        Finish[i] = 0;
    }

    int deadlockCount = 0;

    // Step 2: Find an index i such that Finish[i] == 0 and Request[i] <= Work
    int found;
    do {
        found = 0;
        for (int i = 0; i < N; ++i) {
            if (!Finish[i]) {
                int canFinish = 1;
                for (int j = 0; j < M; ++j) {
                    if (Request[i][j] > Work[j]) {
                        canFinish = 0;
                        break;
                    }
                }

                if (canFinish) {
                    // Step 3: Update Work and Finish
                    for (int j = 0; j < M; ++j) {
                        Work[j] += Allocation[i][j];
                    }
                    Finish[i] = 1;
                    found = 1;
                }
            }
        }
    } while (found);

    // Step 4: Check if Finish[i] == 0 for some i
    for (int i = 0; i < N; ++i) {
        if (!Finish[i]) {
            // System is in deadlock state
            deadlockCount++;
        }
    }


    // Step 5: Return the number of deadlocked processes
    pthread_mutex_unlock(&mutex);
    return deadlockCount;
}


void rm_print_state(char headermsg[]) {
    pthread_mutex_lock(&mutex);

    int space = 3;
    if (M == 100) {
        space = 5;
    } else if (M >= 10) {
        space = 4;
    }

    printf("\n");
    printf("##########################\n");
    printf("%s\n", headermsg);
    printf("##########################\n");

    // Print Existing vector
    printf("Exist:\n     ");
    for (int i = 0; i < M; ++i) {
        printf("R%-*d", space - 1, i);
    }
    printf("\n     ");
    for (int i = 0; i < M; ++i) {
        printf("%-*d", space, ExistingRes[i]);
    }
    printf("\n");
    printf("\n");

    // Print Available vector
    printf("Available:\n     ");
    for (int i = 0; i < M; ++i) {
        printf("R%-*d", space - 1, i);
    }
    printf("\n     ");
    for (int i = 0; i < M; ++i) {
        printf("%-*d", space, Available[i]);
    }
    printf("\n");
    printf("\n");

    // Print Allocation matrix
    printf("Allocation:\n     ");
    for (int i = 0; i < M; ++i) {
        printf("R%-*d", space - 1, i);
    }
    printf("\n");
    for (int i = 0; i < N; ++i) {
        printf("T%d:  ", i);
        for (int j = 0; j < M; ++j) {
            printf("%-*d", space, Allocation[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    // Print Request matrix
    printf("Request:\n     ");
    for (int i = 0; i < M; ++i) {
        printf("R%-*d", space - 1, i);
    }
    printf("\n");
    for (int i = 0; i < N; ++i) {
        printf("T%d:  ", i);
        for (int j = 0; j < M; ++j) {
            printf("%-*d", space, Request[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    // Print MaxDemand matrix
    printf("MaxDemand:\n     ");
    for (int i = 0; i < M; ++i) {
        printf("R%-*d", space - 1, i);
    }
    printf("\n");
    for (int i = 0; i < N; ++i) {
        printf("T%d:  ", i);
        for (int j = 0; j < M; ++j) {
            printf("%-*d", space, MaxDemand[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    printf("Need:\n     ");
    for (int i = 0; i < M; ++i) {
        printf("R%-*d", space - 1, i);
    }
    printf("\n");

    for (int i = 0; i < N; ++i) {
        printf("T%d:  ", i);
        for (int j = 0; j < M; ++j) {
            printf("%-*d", space, Need[i][j]);
        }
        printf("\n");
    }

    printf("##########################\n");
    printf("\n");

    pthread_mutex_unlock(&mutex);
}
