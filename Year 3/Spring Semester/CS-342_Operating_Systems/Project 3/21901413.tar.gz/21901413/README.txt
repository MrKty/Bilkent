Ömer Oktay Gültekin 21901413 Section 1
