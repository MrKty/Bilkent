#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdarg.h>
#include "rm.h"

#define NUMR 5        // number of resource types
#define NUMP 3        // number of threads

int AVOID = 1;
int exist[NUMR] = {8, 8, 8, 8, 8};  // resources existing in the system

void pr(int tid, char astr[], int m, int r[]) {
    int i;
    printf("thread %d, %s, [", tid, astr);
    for (i = 0; i < m; ++i) {
        if (i == (m - 1))
            printf("%d", r[i]);
        else
            printf("%d,", r[i]);
    }
    printf("]\n");
}

void setarray(int r[NUMR], int m, ...) {
    va_list valist;
    int i;

    va_start (valist, m);
    for (i = 0; i < m; i++) {
        r[i] = va_arg(valist, int);
    }
    va_end(valist);
    return;
}

void *threadfunc1(void *a) {
    int tid;
    int request1[NUMR];
    int request2[NUMR];
    int request3[NUMR];
    int claim[NUMR];

    tid = *((int *) a);
    rm_thread_started(tid);

    setarray(claim, NUMR, 8, 8, 0, 0, 8);
    rm_claim(claim);


    setarray(request1, NUMR, 0, 8, 0, 0, 0);
    pr(tid, "REQ", NUMR, request1);
    rm_request(request1);
    rm_print_state("The current state");


    sleep(2);

    setarray(request2, NUMR, 8, 0, 0, 0, 0);
    pr(tid, "REQ", NUMR, request2);
    rm_request(request2);
    rm_print_state("The current state");


    sleep(2);

    setarray(request3, NUMR, 0, 0, 0, 0, 8);
    pr(tid, "REQ", NUMR, request3);
    rm_request(request3);
    rm_print_state("The current state");

    sleep(2);

    pr(tid, "REL", NUMR, request1);
    rm_release(request1);
    rm_print_state("The current state");

    pr(tid, "REL", NUMR, request2);
    rm_release(request2);
    rm_print_state("The current state");

    pr(tid, "REL", NUMR, request3);
    rm_release(request3);
    rm_print_state("The current state");

    rm_thread_ended();
    pthread_exit(NULL);
}

void *threadfunc2(void *a) {
    int tid;
    int request1[NUMR];
    int request2[NUMR];
    int request3[NUMR];
    int claim[NUMR];

    tid = *((int *) a);
    rm_thread_started(tid);

    setarray(claim, NUMR, 8, 8, 8, 0, 0);
    rm_claim(claim);

    setarray(request1, NUMR, 8, 0, 0, 0, 0);
    pr(tid, "REQ", NUMR, request1);
    rm_request(request1);
    rm_print_state("The current state");

    sleep(2);

    setarray(request2, NUMR, 0, 8, 0, 0, 0);
    pr(tid, "REQ", NUMR, request2);
    rm_request(request2);
    rm_print_state("The current state");

    sleep(2);

    setarray(request3, NUMR, 0, 0, 8, 0, 0);
    pr(tid, "REQ", NUMR, request3);
    rm_request(request3);
    rm_print_state("The current state");

    sleep(2);

    pr(tid, "REL", NUMR, request1);
    rm_release(request1);
    rm_print_state("The current state");

    pr(tid, "REL", NUMR, request2);
    rm_release(request2);
    rm_print_state("The current state");

    pr(tid, "REL", NUMR, request3);
    rm_release(request3);
    rm_print_state("The current state");

    rm_thread_ended();
    pthread_exit(NULL);
}

void *threadfunc3(void *a) {
    int tid;
    int request1[NUMR];
    int request2[NUMR];
    int request3[NUMR];
    int request4[NUMR];
    int request5[NUMR];
    int claim[NUMR];

    tid = *((int *) a);
    rm_thread_started(tid);

    setarray(claim, NUMR, 0, 0, 8, 8, 8);
    rm_claim(claim);

    setarray(request1, NUMR, 0, 0, 8, 0, 0);
    pr(tid, "REQ", NUMR, request1);
    rm_request(request1);
    rm_print_state("The current state");

    sleep(2);

    setarray(request2, NUMR, 0, 0, 0, 8, 0);
    pr(tid, "REQ", NUMR, request2);
    rm_request(request2);
    rm_print_state("The current state");

    sleep(2);

    setarray(request3, NUMR, 0, 0, 0, 0, 8);
    pr(tid, "REQ", NUMR, request3);
    rm_request(request3);
    rm_print_state("The current state");

    sleep(2);

    pr(tid, "REL", NUMR, request1);
    rm_release(request1);
    rm_print_state("The current state");

    pr(tid, "REL", NUMR, request2);
    rm_release(request2);
    rm_print_state("The current state");

    setarray(request4, NUMR, 0, 0, 0, 0, 5);
    pr(tid, "REL", NUMR, request4);
    rm_release(request4);
    rm_print_state("The current state");

    setarray(request5, NUMR, 0, 0, 0, 0, 3);
    pr(tid, "REL", NUMR, request5);
    rm_release(request5);
    rm_print_state("The current state");

    rm_thread_ended();
    pthread_exit(NULL);
}

int main(int argc, char **argv) {
    int i;
    int tids[NUMP];
    pthread_t threadArray[NUMP];
    int count;
    int ret;

    if (argc != 2) {
        printf("usage: ./app avoidflag\n");
        exit(1);
    }

    AVOID = atoi(argv[1]);

    if (AVOID == 1)
        rm_init(NUMP, NUMR, exist, 1);
    else
        rm_init(NUMP, NUMR, exist, 0);

    i = 0;  // we select a tid for the thread
    tids[i] = i;
    pthread_create(&(threadArray[i]), NULL,
                   (void *) threadfunc1, (void *) &tids[i]);

    i = 1;  // we select a tid for the thread
    tids[i] = i;
    pthread_create(&(threadArray[i]), NULL,
                   (void *) threadfunc2, (void *) &tids[i]);

    i = 2;  // we select a tid for the thread
    tids[i] = i;
    pthread_create(&(threadArray[i]), NULL,
                   (void *) threadfunc3, (void *) &tids[i]);

    count = 0;
    while (count < 10) {
        sleep(1);
        rm_print_state("The current state");
        ret = rm_detection();
        if (ret > 0) {
            printf("deadlock detected, count=%d\n", ret);
            rm_print_state("state after deadlock");
        }
        count++;
    }

    if (ret == 0) {
        for (i = 0; i < NUMP; ++i) {
            pthread_join(threadArray[i], NULL);
            printf("joined\n");
        }
    }
}