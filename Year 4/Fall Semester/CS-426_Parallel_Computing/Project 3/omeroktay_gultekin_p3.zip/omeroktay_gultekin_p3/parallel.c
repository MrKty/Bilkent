#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <omp.h>

void InitializeAndReadMatrix(const char *fileName, int size, double matrix[size][size])
{
    FILE *file = fopen(fileName, "r");
    if (file == NULL)
    {
        fprintf(stderr, "Error opening %s\n", fileName);
        exit(1);
    }

    int matrixSize;
    fscanf(file, "%d", &matrixSize); // Skip the size line

    for (int i = 0; i < size; ++i)
    {
        for (int j = 0; j < size; ++j)
        {
            fscanf(file, "%lf", &matrix[i][j]);
        }
    }
    fclose(file);
}

void printMatrix(int size, double matrix[size][size])
{
    for (int i = 0; i < size; ++i)
    {
        for (int j = 0; j < size; ++j)
        {
            printf("%.2lf ", matrix[i][j]);
        }
        printf("\n");
    }
}

void print3dMatrix(int size, double matrix[size][size][3])
{
    for (int k = 0; k < 3; ++k)
    {
        printf("Channel %d:\n", k);
        for (int i = 0; i < size; ++i)
        {
            for (int j = 0; j < size; ++j)
            {
                printf("%.2lf ", matrix[i][j][k]);
            }
            printf("\n");
        }
    }
}

void print3DFormattedMatrix(int size, double matrix[size][size][3])
{
    for (int k = 0; k < 3; ++k)
    {
        printf("Channel %d:\n", k);
        for (int i = 0; i < size; ++i)
        {
            for (int j = 0; j < size; ++j)
            {
                printf("%.8le ", matrix[i][j][k]);
            }
            printf("\n");
        }
    }
}

void write3dLongDoubleMatrixToFile(int size, double matrix[size][size][3], FILE *file)
{
    fprintf(file, "[[[");
    for (int k = 0; k < 3; ++k)
    {
        if (k > 0)
        {
            fprintf(file, " [[");
        }
        for (int i = 0; i < size; ++i)
        {
            if (i > 0)
            {
                fprintf(file, "  [");
            }
            for (int j = 0; j < size; ++j)
            {
                fprintf(file, "%.8le", matrix[i][j][k]);
                if (j < size - 1)
                {
                    fprintf(file, " ");
                }
            }
            fprintf(file, "]");
            if (i < size - 1)
            {
                fprintf(file, "\n");
            }
        }
        if (k < 2)
        {
            fprintf(file, "]\n\n");
        }
    }
    fprintf(file, "]]");
}

double sigmoid(double x)
{
    return 1.0L / (1.0L + exp(-x));
}

void applyZeroPadding(int size, int paddedSize, double inputMatrix[][size], int inputSize, int padding, double paddedMatrix[][paddedSize])
{
    #pragma omp parallel for collapse(2)
    for (int i = 0; i < paddedSize; ++i)
    {
        for (int j = 0; j < paddedSize; ++j)
        {
            if (i < padding || i >= inputSize + padding || j < padding || j >= inputSize + padding)
            {
                paddedMatrix[i][j] = 0;
            }
            else
            {
                paddedMatrix[i][j] = inputMatrix[i - padding][j - padding];
            }
        }
    }
}

void applySigmoidActivation(int inputSize, double outputMatrix[][inputSize][3], double sigmoidMatrix[][inputSize][3])
{
    #pragma omp parallel for collapse(2)
    for (int i = 0; i < inputSize; ++i)
    {
        for (int j = 0; j < inputSize; ++j)
        {
            for (int k = 0; k < 3; ++k)
            {
                sigmoidMatrix[i][j][k] = sigmoid(outputMatrix[i][j][k]);
            }
        }
    }
}

void applyMaxPooling(int inputSize, double sigmoidMatrix[][inputSize][3], int poolSize, double maxPoolingMatrix[][inputSize / 2][3])
{
    #pragma omp parallel for collapse(2)
    for (int k = 0; k < 3; ++k)
    {
        for (int i = 0; i < inputSize / 2; ++i)
        {
            for (int j = 0; j < inputSize / 2; ++j)
            {
                double max = 0;
                for (int l = 0; l < 2; ++l)
                {
                    for (int m = 0; m < 2; ++m)
                    {
                        if (sigmoidMatrix[i * 2 + l][j * 2 + m][k] > max)
                        {
                            max = sigmoidMatrix[i * 2 + l][j * 2 + m][k];
                        }
                    }
                }
                maxPoolingMatrix[i][j][k] = max;
            }
        }
    }
}

int main()
{

    // measure time
    clock_t start, end;
    double cpu_time_used;
    start = clock();

    // Number of threads program can use
    int num_threads = omp_get_max_threads();
    omp_set_num_threads(num_threads);

    int inputSize;
    FILE *inputFile = fopen("input.txt", "r");
    fscanf(inputFile, "%d", &inputSize);
    fclose(inputFile);

    int kernelSize;
    FILE *kernel1File = fopen("kernel1.txt", "r");
    fscanf(kernel1File, "%d", &kernelSize);
    fclose(kernel1File);

    // Read matrices
    double inputMatrix[inputSize][inputSize];
    double kernel1Matrix[kernelSize][kernelSize];
    double kernel2Matrix[kernelSize][kernelSize];
    double kernel3Matrix[kernelSize][kernelSize];

    InitializeAndReadMatrix("input.txt", inputSize, inputMatrix);
    InitializeAndReadMatrix("kernel1.txt", kernelSize, kernel1Matrix);
    InitializeAndReadMatrix("kernel2.txt", kernelSize, kernel2Matrix);
    InitializeAndReadMatrix("kernel3.txt", kernelSize, kernel3Matrix);

    // Print matrices
    printf("Input matrix:\n");
    printMatrix(inputSize, inputMatrix);
    printf("Kernel 1 matrix:\n");
    printMatrix(kernelSize, kernel1Matrix);
    printf("Kernel 2 matrix:\n");
    printMatrix(kernelSize, kernel2Matrix);
    printf("Kernel 3 matrix:\n");
    printMatrix(kernelSize, kernel3Matrix);

    // Calculate the padding size where stride = 1
    int padding = (kernelSize - 1) / 2;

    // Apply zero padding to the input matrix
    int paddedSize = inputSize + padding * 2;
    double paddedInputMatrix[paddedSize][paddedSize];
    applyZeroPadding(inputSize, paddedSize, inputMatrix, inputSize, padding, paddedInputMatrix);

    // print padded input matrix
    printf("Padded input matrix:\n");
    printMatrix(paddedSize, paddedInputMatrix);

    double outputMatrix[inputSize][inputSize][3];

    // convolution
    #pragma omp parallel for collapse(2)
    for (int i = 0; i < inputSize; ++i)
    {
        for (int j = 0; j < inputSize; ++j)
        {
            double sum1 = 0, sum2 = 0, sum3 = 0;
            #pragma omp parallel for reduction(+ : sum1, sum2, sum3)
            for (int k = 0; k < kernelSize; ++k)
            {
                for (int l = 0; l < kernelSize; ++l)
                {
                    sum1 += paddedInputMatrix[i + k][j + l] * kernel1Matrix[k][l];
                    sum2 += paddedInputMatrix[i + k][j + l] * kernel2Matrix[k][l];
                    sum3 += paddedInputMatrix[i + k][j + l] * kernel3Matrix[k][l];
                }
            }
            outputMatrix[i][j][0] = sum1;
            outputMatrix[i][j][1] = sum2;
            outputMatrix[i][j][2] = sum3;
        }
    }

    // print output matrix
    printf("Output matrix:\n");
    print3dMatrix(inputSize, outputMatrix);

    double sigmoidMatrix[inputSize][inputSize][3];
    applySigmoidActivation(inputSize, outputMatrix, sigmoidMatrix);

    // print sigmoid matrix
    printf("Sigmoid matrix:\n");
    print3DFormattedMatrix(inputSize, sigmoidMatrix);

    double maxPoolingMatrix[inputSize / 2][inputSize / 2][3];

    // max pooling
    applyMaxPooling(inputSize, sigmoidMatrix, 2, maxPoolingMatrix);

    // print max pooling matrix
    printf("Max pooling matrix:\n");
    print3DFormattedMatrix(inputSize / 2, maxPoolingMatrix);

    // 6 – Write the result into output.txt.
    FILE *outputFile = fopen("output.txt", "w");
    write3dLongDoubleMatrixToFile(inputSize / 2, maxPoolingMatrix, outputFile);
    fclose(outputFile);

    // measure time (gprof is more accurate)
    end = clock();

    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
    printf("Time taken: %f\n", cpu_time_used);

    return 0;
}