#!/bin/bash

# Compile and run the parallel program
gcc -pg -fopenmp -o parallel parallel.c -lm
./parallel
echo "Profiling for Parallel Program with input 280x280 and kernels 225x225, 8 thread:" >> prof_parallel.txt
gprof parallel gmon.out >> prof_parallel.txt

# Compile and run the serial program
gcc -pg -o serial serial.c -lm
./serial
echo "Profiling for Serial Program  with input 200x200 and kernels 81x81:" >> prof_sequential.txt
gprof serial gmon.out >> prof_sequential.txt