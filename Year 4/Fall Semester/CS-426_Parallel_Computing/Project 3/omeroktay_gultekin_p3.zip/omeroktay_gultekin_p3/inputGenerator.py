import random

# Function to generate a 2D matrix of doubles
def generate_double_matrix(rows, cols):
    return [[random.uniform(0, 100) for _ in range(cols)] for _ in range(rows)]

# Function to write matrix data to a file
def write_matrix_to_file(filename, matrix):
    with open(filename, 'w') as file:
        file.write(f"{len(matrix)}\n")  # Write the size of the matrix
        for row in matrix:
            file.write(' '.join(f"{num:.2f}" for num in row) + '\n')

# Main code
rows, cols = 280, 280  # Example dimensions for input matrix
kernel_size = 225  # Kernel dimensions are half of the input

# Generate and write input matrix
input_matrix = generate_double_matrix(rows, cols)
write_matrix_to_file('input.txt', input_matrix)

# Generate and write kernel matrices
for i in range(1, 4):
    kernel_matrix = generate_double_matrix(kernel_size, kernel_size)
    write_matrix_to_file(f'kernel{i}.txt', kernel_matrix)

print("Matrix files created successfully.")
