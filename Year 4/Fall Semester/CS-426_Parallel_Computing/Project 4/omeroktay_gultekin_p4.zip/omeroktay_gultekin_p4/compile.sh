#!/bin/bash

# Compile kmer_serial.cu
nvcc -std=c++14 -I . -o kmer_serial kmer_serial.cu util.cu

# Compile kmer_parallel.cu
nvcc -std=c++14 -I . -o kmer_parallel kmer_parallel.cu util.cu