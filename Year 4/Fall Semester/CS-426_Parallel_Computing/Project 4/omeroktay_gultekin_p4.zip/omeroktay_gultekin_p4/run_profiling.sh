#!/bin/bash

# Compile and run the parallel program
nvcc -std=c++14 -I . -o kmer_parallel kmer_parallel.cu util.cu
./kmer_parallel ./reference.txt ./read.txt 3 ./output_parallel.txt
echo "Profiling for Parallel Program:" >> prof_parallel.txt
nsight-sys profile ./kmer_parallel >> prof_parallel.txt

# Compile and run the serial program
nvcc -std=c++14 -I . -o kmer_serial kmer_serial.cu util.cu
./kmer_serial ./reference.txt ./read.txt 3 ./output_serial.txt
echo "Profiling for Serial Program:" >> prof_serial.txt
nsight-sys profile ./kmer_serial >> prof_serial.txt
