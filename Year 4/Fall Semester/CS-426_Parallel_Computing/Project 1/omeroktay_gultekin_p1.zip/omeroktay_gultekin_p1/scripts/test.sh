#!/bin/bash

cd ..

# Compile serial.c with gcc
gcc serial.c -o serial -lm

# Compile parallel.c with mpicc
mpicc parallel.c -o parallel -lm

# Run the serial program
./serial

# Function to run the parallel program and compare results
function runParallel {
    echo "Running parallel program with $1 processes"
    mpirun -np $1 parallel
    #var=$(python3 resultComparator.py)
    #if [ "$var" = "False" ]
    #then
    #    echo "The results are different"
    #fi
}

# Run the parallel program with different process counts
runParallel 1
runParallel 2
runParallel 4
runParallel 6
