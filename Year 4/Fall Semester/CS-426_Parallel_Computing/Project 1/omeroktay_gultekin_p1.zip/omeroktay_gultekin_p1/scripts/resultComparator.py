def compare_files(file1, file2):
    with open(file1, 'r') as f1, open(file2, 'r') as f2:
        content1 = f1.read()
        content2 = f2.read()
        return content1 == content2

result_same = compare_files('result.txt', 'result1.txt')
print(f"{result_same}")
