import random

# Function to generate a matrix
def generate_matrix(rows, cols):
    return [[random.uniform(-5, 5) for _ in range(cols)] for _ in range(rows)]

# Function to generate a vector for bias
def generate_bias(size):
    return [random.uniform(-5, 5) for _ in range(size)]

# Function to write matrix data to a file
def write_matrix_to_file(filename, data, rows, cols):
    with open(filename, 'w') as file:
        file.write(f"{rows} {cols}\n")
        for row in data:
            file.write(' '.join(map(str, row)) + '\n')

# Function to write bias data to a file
def write_bias_to_file(filename, data, size):
    with open(filename, 'w') as file:
        file.write(f"{size}\n")
        file.write('\n'.join(map(str, data)))

# Define matrix dimensions
input_rows = 600
input_cols = 1000
weight_rows = 800
weight_cols = 600
bias_size = 800

# Generate matrices and bias vector
input_matrix = generate_matrix(input_rows, input_cols)
weight_matrix = generate_matrix(weight_rows, weight_cols)
bias_vector = generate_bias(bias_size)

# Write data to files
write_matrix_to_file('../input.txt', input_matrix, input_rows, input_cols)
write_matrix_to_file('../weightmatrix.txt', weight_matrix, weight_rows, weight_cols)
write_bias_to_file('../bias.txt', bias_vector, bias_size)
