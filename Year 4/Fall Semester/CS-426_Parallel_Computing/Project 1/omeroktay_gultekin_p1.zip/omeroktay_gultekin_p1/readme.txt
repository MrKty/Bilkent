Ömer Oktay Gültekin
21901413

Project 1

The code assumes the matrixes given under the name input.txt, weight.txt, and bias.txt. Result goes to result.txt.
In the script folder, there are useful scripts that I used in testing. You can use test.sh to test the code with various parameters.

You can create executables by:

For serial -> gcc serial.c -o serial -lm
For parallel -> mpicc parallel.c -o parallel -lm

or you can use Makefile directly by typing make.

