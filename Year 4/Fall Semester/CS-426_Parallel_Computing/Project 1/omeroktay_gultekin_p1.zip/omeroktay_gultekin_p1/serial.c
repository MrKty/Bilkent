#include <stdio.h>
#include <math.h>
#include <time.h>

float applySigmoidFunction(float x) {
    return 1.0 / (1.0 + exp(-x));
}

void readMatrix(FILE *file, int rows, int cols, float matrix[rows][cols]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            fscanf(file, "%f", &matrix[i][j]);
        }
    }
}

void readArray(FILE *file, int size, float array[size]) {
    for (int i = 0; i < size; i++) {
        fscanf(file, "%f", &array[i]);
    }
}

void writeMatrix(FILE *file, int rows, int cols, float matrix[rows][cols]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            fprintf(file, "%f ", matrix[i][j]);
        }
        fprintf(file, "\n");
    }
}

void performMatrixMultiplication(int m, int n, int p, float X[n][p], float W[m][n], float b[m], FILE *fileResult) {
    float temp[m][p];
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < p; j++) {
            temp[i][j] = 0.0;
            for (int k = 0; k < n; k++) {
                temp[i][j] += W[i][k] * X[k][j];
            }
            temp[i][j] += b[i];
            temp[i][j] = applySigmoidFunction(temp[i][j]);
        }
    }
    writeMatrix(fileResult, m, p, temp);
}

int main() {
    clock_t start, end;
    double cpu_time_used;

    FILE *fileW, *fileX, *fileB, *fileResult;

    fileW = fopen("weightmatrix.txt", "r");
    fileX = fopen("input.txt", "r");
    fileB = fopen("bias.txt", "r");
    fileResult = fopen("result.txt", "w");

    int m, n, p; // Dimensions of matrices
    int t;       // Dimension of the vector

    fscanf(fileX, "%d %d", &n, &p);
    fscanf(fileW, "%d %d", &m, &n);
    fscanf(fileB, "%d", &t);

    float X[n][p], W[m][n], b[t];
    readMatrix(fileX, n, p, X);
    readMatrix(fileW, m, n, W);
    readArray(fileB, t, b);

    start = clock();

    performMatrixMultiplication(m, n, p, X, W, b, fileResult);

    fclose(fileW);
    fclose(fileX);
    fclose(fileB);
    fclose(fileResult);

    end = clock();
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Time taken: %f seconds\n", cpu_time_used);

    return 0;
}