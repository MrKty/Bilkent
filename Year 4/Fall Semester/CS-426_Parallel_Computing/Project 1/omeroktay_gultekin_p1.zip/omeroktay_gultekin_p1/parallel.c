#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mpi.h"
#include <time.h>

float applySigmoidFunction(float x)
{
    return 1.0 / (1.0 + exp(-x));
}

void readMatrix(FILE *file, int rows, int cols, float matrix[rows][cols]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            fscanf(file, "%f", &matrix[i][j]);
        }
    }
}

void readArray(FILE *file, int size, float array[size]) {
    for (int i = 0; i < size; i++) {
        fscanf(file, "%f", &array[i]);
    }
}

void writeMatrix(FILE *file, int rows, int cols, float matrix[rows][cols]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            fprintf(file, "%f ", matrix[i][j]);
        }
        fprintf(file, "\n");
    }
}

int main(int argc, char *argv[])
{
    clock_t start, end;
    double cpu_time_used;
    int rank, size;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Master process
    if (rank == 0)
    {
        FILE *fileW, *fileX, *fileB, *fileResult;

        int m, n, p; // Dimensions of matrices
        int t;       // Dimension of the vector

        fileW = fopen("weightmatrix.txt", "r");
        fileX = fopen("input.txt", "r");
        fileB = fopen("bias.txt", "r");
        fileResult = fopen("result.txt", "w");

        // Read dimensions of matrices
        fscanf(fileX, "%d %d", &n, &p);
        fscanf(fileW, "%d %d", &m, &n);
        fscanf(fileB, "%d", &t);

        // Declare matrices
        float X[n][p], W[m][n], b[t];
        readMatrix(fileX, n, p, X);
        readMatrix(fileW, m, n, W);
        readArray(fileB, t, b);

        start = clock();

        float temp[m][p];

        // Calculate rows for each process
        int rows_per_process = m / size;
        int start_row = 0;
        int end_row = 0;
        for (int dest = 1; dest < size; dest++)
        {
            start_row = (dest - 1) * rows_per_process;
            end_row = start_row + rows_per_process;
            MPI_Send(&n, 1, MPI_INT, dest, 0, MPI_COMM_WORLD);
            MPI_Send(&p, 1, MPI_INT, dest, 0, MPI_COMM_WORLD);
            MPI_Send(&rows_per_process, 1, MPI_INT, dest, 0, MPI_COMM_WORLD);

            MPI_Send(&W[start_row], (end_row - start_row) * n, MPI_FLOAT, dest, 0, MPI_COMM_WORLD);
            MPI_Send(&X, n * p, MPI_FLOAT, dest, 0, MPI_COMM_WORLD);
            MPI_Send(&b[start_row], rows_per_process, MPI_FLOAT, dest, 0, MPI_COMM_WORLD);
        }

        // Master process' own computation
        for (int i = end_row; i < m; i++)
        {
            for (int j = 0; j < p; j++)
            {
                temp[i][j] = 0.0;
                for (int k = 0; k < n; k++)
                {
                    temp[i][j] += W[i][k] * X[k][j];
                }
                temp[i][j] += b[i];
                temp[i][j] = applySigmoidFunction(temp[i][j]);
            }
        }

        // Gather the results from other processes
        for (int src = 1; src < size; src++)
        {
            MPI_Recv(&temp[rows_per_process * (src - 1)], rows_per_process * p, MPI_FLOAT, src, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        // Write the result to 'result.txt'
        writeMatrix(fileResult, m, p, temp);

        fclose(fileW);
        fclose(fileX);
        fclose(fileB);
        fclose(fileResult);

        end = clock();                                            // Record the end time
        cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC; // Calculate time taken
        printf("Time taken: %f seconds\n", cpu_time_used);        // Display the time taken
    }

    // Other processes' computation
    else
    {
        int n, p;
        int rows_per_process;

        MPI_Recv(&n, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&p, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&rows_per_process, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        float W[rows_per_process][n], X[n][p], b[rows_per_process];
        float temp[rows_per_process][p];

        MPI_Recv(&W, rows_per_process * n, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&X, n * p, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&b, rows_per_process, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        for (int i = 0; i < rows_per_process; i++)
        {
            for (int j = 0; j < p; j++)
            {
                temp[i][j] = 0.0;
                for (int k = 0; k < n; k++)
                {
                    temp[i][j] += W[i][k] * X[k][j];
                }
                temp[i][j] += b[i];
                temp[i][j] = applySigmoidFunction(temp[i][j]);
            }
        }

        MPI_Send(&temp, rows_per_process * p, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Finalize();

    return 0;
}