#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>
#include <time.h>
#include <vector>

using namespace std;

void customQuicksort(int array[], int left, int right)
{
    if (left < right)
    {
        int pivot = array[right];
        int partitionIndex = left - 1;

        for (int currentIdx = left; currentIdx < right; ++currentIdx)
        {
            if (array[currentIdx] <= pivot)
            {
                ++partitionIndex;

                int temp = array[partitionIndex];
                array[partitionIndex] = array[currentIdx];
                array[currentIdx] = temp;
            }
        }

        int temp = array[partitionIndex + 1];
        array[partitionIndex + 1] = array[right];
        array[right] = temp;

        customQuicksort(array, left, partitionIndex);
        customQuicksort(array, partitionIndex + 2, right);
    }
}

int main(int argc, char *argv[])
{
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (argc != 3)
    {
        if (rank == 0)
        {
            std::cerr << "Usage: " << argv[0] << " <input_file> <output_file>\n";
        }
        MPI_Finalize();
        return 1;
    }

    const char *inputFileName = argv[1];
    const char *outputFileName = argv[2];

    std::vector<int> tempNumbers;
    int num, count = 0;
    int dimension = static_cast<int>(std::log2(size));

    if (rank == 0)
    {
        std::ifstream inputFile(inputFileName);
        if (!inputFile.is_open())
        {
            std::cerr << "Error opening input file.\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        while (inputFile >> num)
        {
            tempNumbers.push_back(num);
            ++count;
        }

        inputFile.close();
    }

    int *numbers = tempNumbers.data();

    clock_t start = clock();

    int localSize = count / size;

    // Broadcast the localSize to all processes
    MPI_Bcast(&localSize, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);

    int *localArray = new int[localSize];

    MPI_Scatter(numbers, localSize, MPI_INT, localArray, localSize, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);

    MPI_Comm newComm = MPI_COMM_WORLD;
    int subRank = rank, subSize = size;

    for (int i = 0; i < dimension; ++i)
    {
        if (i != 0)
        {
            MPI_Comm_split(newComm, rank / (1 << i), rank, &newComm);
            MPI_Comm_rank(newComm, &subRank);
            MPI_Comm_size(newComm, &subSize);
        }

        customQuicksort(localArray, 0, localSize - 1);
        int median = localArray[localSize / 2];
        int medians[subSize];

        MPI_Allgather(&median, 1, MPI_INT, medians, 1, MPI_INT, newComm);
        MPI_Barrier(newComm);

        customQuicksort(medians, 0, subSize - 1);
        median = medians[subSize / 2];

        int *upper = new int[localSize];
        int *lower = new int[localSize];
        int upperSize = 0, lowerSize = 0;

        for (int i = 0; i < localSize; ++i)
        {
            if (localArray[i] > median)
            {
                upper[upperSize++] = localArray[i];
            }
            else
            {
                lower[lowerSize++] = localArray[i];
            }
        }

        int bitmask = 1 << (dimension - i - 1);
        int partner = rank ^ bitmask;

        int sizeToChange = -1;
        if (rank < partner)
        {
            sizeToChange = upperSize;
        }
        else
        {
            sizeToChange = lowerSize;
        }

        int partnerSize;
        MPI_Sendrecv(&sizeToChange, 1, MPI_INT, partner, 0, &partnerSize, 1, MPI_INT, partner, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Barrier(MPI_COMM_WORLD);

        int *partnerArray = new int[partnerSize];

        MPI_Sendrecv((rank < partner) ? upper : lower, sizeToChange, MPI_INT, partner, 0, partnerArray, partnerSize, MPI_INT, partner, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Barrier(MPI_COMM_WORLD);

        if (rank < partner)
        {
            delete[] upper;

            upper = new int[partnerSize];
            for (int i = 0; i < partnerSize; ++i)
            {
                upper[i] = partnerArray[i];
            }

            localSize = partnerSize + lowerSize;
            upperSize = partnerSize;
        }
        else
        {
            delete[] lower;

            lower = new int[partnerSize];
            for (int i = 0; i < partnerSize; ++i)
            {
                lower[i] = partnerArray[i];
            }

            localSize = partnerSize + upperSize;
            lowerSize = partnerSize;
        }

        delete[] partnerArray;
        delete[] localArray;
        // 6.2 Merge the two arrays
        int *mergedArray = new int[localSize];
        int l = 0, j = 0, k = 0;
        while (l < lowerSize && j < upperSize)
        {
            if (lower[l] < upper[j])
            {
                mergedArray[k++] = lower[l++];
            }
            else
            {
                mergedArray[k++] = upper[j++];
            }
        }

        while (l < lowerSize)
        {
            mergedArray[k++] = lower[l++];
        }

        while (j < upperSize)
        {
            mergedArray[k++] = upper[j++];
        }

        localArray = new int[localSize];
        for (int i = 0; i < localSize; ++i)
        {
            localArray[i] = mergedArray[i];
        }

        delete[] mergedArray;
    }

    // Gather the mergedArray to all processes using MPI_Gatherv
    int *numberCounts = nullptr;
    int *displacements = nullptr;

    if (rank == 0)
    {
        numberCounts = new int[size];
        displacements = new int[size];
    }

    MPI_Gather(&localSize, 1, MPI_INT, numberCounts, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);

    if (rank == 0)
    {
        displacements[0] = 0;
        for (int i = 1; i < size; ++i)
        {
            displacements[i] = displacements[i - 1] + numberCounts[i - 1];
        }
    }

    MPI_Gatherv(localArray, localSize, MPI_INT, numbers, numberCounts, displacements, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);

    if (rank == 0)
    {
        clock_t end = clock();

        double elapsed_time = static_cast<double>(end - start) / CLOCKS_PER_SEC;
        std::cout << "Elapsed time: " << elapsed_time << " seconds\n";

        std::ofstream outputFile(outputFileName);
        if (!outputFile.is_open())
        {
            std::cerr << "Error opening output file.\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        for (int i = 0; i < count; ++i)
        {
            outputFile << numbers[i] << "\n";
        }

        cout << "Sorting complete. Sorted array written to " << outputFileName << "\n";

        delete[] numberCounts;
        delete[] displacements;
    }

    // Each processor creates a separate output file based on its rank
    string filename = "output" + to_string(rank) + ".txt";
    std::ofstream outputFile(filename);
    if (!outputFile.is_open())
    {
        std::cerr << "Error opening output file for process " << rank << ".\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    // Write localArray to the corresponding output file
    for (int i = 0; i < localSize; ++i)
    {
        outputFile << localArray[i] << "\n";
    }

    cout << "Process " << rank << " completed. Local array written to " << filename << "\n";

    MPI_Finalize();

    return 0;
}