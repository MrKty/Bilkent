#include <iostream>
#include <fstream>
#include <vector>
#include <time.h>

void customQuicksort(std::vector<int>& array, int left, int right)
{
    if (left < right)
    {
        int pivot = array[right];
        int partitionIndex = left - 1;

        for (int currentIndex = left; currentIndex < right; ++currentIndex)
        {
            if (array[currentIndex] <= pivot)
            {
                ++partitionIndex;
                // Swap array[partitionIndex] and array[currentIndex]
                int temp = array[partitionIndex];
                array[partitionIndex] = array[currentIndex];
                array[currentIndex] = temp;
            }
        }

        // Swap array[partitionIndex + 1] and array[right]
        int temp = array[partitionIndex + 1];
        array[partitionIndex + 1] = array[right];
        array[right] = temp;

        // Recursive calls for the left and right partitions
        customQuicksort(array, left, partitionIndex);
        customQuicksort(array, partitionIndex + 2, right);
    }
}

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        std::cerr << "Usage: " << argv[0] << " <input_file> <output_file>\n";
        return 1;
    }

    const char* inputFileName = argv[1];
    const char* outputFileName = argv[2];

    std::vector<int> inputArray;
    int inputValue;

    // Read input from file
    std::ifstream inputFile(inputFileName);
    if (!inputFile.is_open())
    {
        std::cerr << "Error opening input file: " << inputFileName << "\n";
        return 1;
    }

    while (inputFile >> inputValue)
    {
        inputArray.push_back(inputValue);
    }

    inputFile.close();

    clock_t start = clock();

    customQuicksort(inputArray, 0, inputArray.size() - 1);

    clock_t end = clock();

    double elapsed_time = static_cast<double>(end - start) / CLOCKS_PER_SEC;
    std::cout << "Elapsed time: " << elapsed_time << " seconds\n";

    // Write sorted output to file
    std::ofstream outputFile(outputFileName);
    if (!outputFile.is_open())
    {
        std::cerr << "Error opening output file: " << outputFileName << "\n";
        return 1;
    }

    for (int index = 0; index < inputArray.size(); ++index)
    {
        outputFile << inputArray[index] << "\n";
    }

    outputFile.close();
    return 0;
}