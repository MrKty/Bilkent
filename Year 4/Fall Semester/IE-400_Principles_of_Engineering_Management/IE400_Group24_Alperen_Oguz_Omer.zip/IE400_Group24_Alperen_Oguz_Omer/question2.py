'''
from gurobipy import Model, GRB, quicksum
from node_calculator import find_current_node


node_index = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7}
node_index_opp = {0:'A', 1:'B', 2:'C', 3:'D', 4:'E', 5:'F', 6:'G', 7:'H'}
depo_index = {'X': 0, 'Y': 1}

model = Model("UrbanRailwayOptimization")
##total travel times
Xi = {1: 17, 2: 17, 3: 16, 4: 11, 5: 20,
                      6: 17, 7: 15, 8: 19, 9: 18, 10: 11,
                      11: 20, 12: 17, 13: 20, 14: 15, 15: 19}


total_travel_times = {1: 17, 2: 17, 3: 16, 4: 11, 5: 20,
                      6: 17, 7: 15, 8: 19, 9: 18, 10: 11,
                      11: 20, 12: 17, 13: 20, 14: 15, 15: 19}

total_trains = 15
max_time = 20
total_depots = 2
total_nodes = 8
# Train type variables (Ei for electric, Di for diesel)
E = {i: model.addVar(vtype=GRB.BINARY, name=f"E_{i}") for i in range(1, total_trains + 1)}
D = {i: model.addVar(vtype=GRB.BINARY, name=f"D_{i}") for i in range(1, total_trains + 1)}

# Battery variables for each train at each time step
B = {(i, k): model.addVar(vtype=GRB.INTEGER, lb=0, ub=8, name=f"B_{i}_{k}") for i in range(1, total_trains + 1) for k in range(max_time + 1)}

# Charging status variables for each train at each node and time
Z = {(i, n, k): model.addVar(vtype=GRB.BINARY, name=f"Z_{i}_{n}_{k}") for i in range(1, total_trains + 1) for k in range(max_time + 1) for n in range(1, total_nodes + 1)}

# Electric station variables for depots and nodes
ElectricStation_Depot = {d: model.addVar(vtype=GRB.INTEGER, name=f"ElectricStation_Depot_{d}") for d in range(1, total_depots + 1)}
ElectricStation_Node = {n: model.addVar(vtype=GRB.INTEGER, name=f"ElectricStation_Node_{n}") for n in range(1, total_nodes + 1)}
FuelStation_Depot = {d: model.addVar(vtype=GRB.INTEGER, name=f"FuelStation_Depot_{d}") for d in range(1, total_depots + 1)}

PeakChargingDemand = {n: model.addVar(vtype=GRB.INTEGER, name=f"PeakChargingDemand_Node_{n}") for n in range(1, total_nodes + 1)}

# Constants for cost calculations
cost_electric_train = 750000
cost_diesel_train = 250000
cost_energy_electric_per_hour = 20000
cost_energy_diesel_per_hour = 100000
cost_in_depot_fuel_station = 800000
cost_in_depot_electric_station = 1000000
cost_on_route_charging_station = 350000

# Objective Function
objective = quicksum(E[i] * cost_electric_train + D[i] * cost_diesel_train for i in range(1, total_trains + 1))
objective += quicksum(E[i] * Xi[i] * cost_energy_electric_per_hour + D[i] * Xi[i] * cost_energy_diesel_per_hour for i in range(1, total_trains + 1))
objective += quicksum(FuelStation_Depot[d] * cost_in_depot_fuel_station for d in range(1, total_depots + 1))
objective += quicksum(ElectricStation_Depot[d] * cost_in_depot_electric_station for d in range(1, total_depots + 1))
objective += quicksum(ElectricStation_Node[n] * cost_on_route_charging_station for n in range(1, total_nodes + 1))

model.setObjective(objective, GRB.MINIMIZE)


# Constraint: Each train is either electric or diesel
for i in range(1, total_trains + 1):
    model.addConstr(E[i] + D[i] == 1, f"TrainTypeConstraint_{i}")

# Constraint: A train cannot be charged if it is not electric
for i in range(1, total_trains + 1):
        for k in range(0, max_time + 1):
            if(find_current_node(i, k)=='X' or find_current_node(i, k)=='Y' ):
                continue
            n =  node_index[find_current_node(i,k)] + 1
            model.addConstr(Z[i, n, k] <= E[i], f"ChargeIfElectric_{i}_{k}")

    

# Constraints for the minimum number of electric and fuel stations at depots
for d in range(1, total_depots + 1):
    model.addConstr(quicksum(E[i] for i in range(1, total_trains + 1)) / 3 <= ElectricStation_Depot[d], f"MinElectricStationsDepot_{d}")
    model.addConstr(quicksum(D[i] for i in range(1, total_trains + 1)) / 2 <= FuelStation_Depot[d], f"MinFuelStationsDepot_{d}")


# Constraint: Number of electric stations at each node
### dikkat et i diye bir şey yok

# Auxiliary variable for the maximum number of trains charging simultaneously at each node
PeakChargingDemand = {n: model.addVar(vtype=GRB.INTEGER, name=f"PeakChargingDemand_Node_{n}") for n in range(1, total_nodes + 1)}

# Update the model to integrate new variables
model.update()

# Set constraints for charging demand at each node
for n in range(1, total_nodes + 1):
    # Determine the maximum charging demand at node n across all times
    model.addConstr(
        quicksum(Z[i, n, k] for i in range(1, total_trains + 1) for k in range(0, 21) if isinstance(find_current_node(i, k), int) and find_current_node(i, k) == n) <= PeakChargingDemand[n],
        f"PeakChargingDemandAtNode_{n}"
    )

    # Ensure at least one charging station if there's demand at any time
    model.addConstr(ElectricStation_Node[n] >= (PeakChargingDemand[n] ), f"ElectricStationAtNode_{n}")

# Constraint: Battery capacity limits for electric trains
for i in range(1, total_trains + 1):
    for k in range(0, total_travel_times[i] + 1):
        model.addConstr(B[i, k] <= 8 * E[i], f"BatteryCapacity_{i}_{k}")
        model.addConstr(B[i, k] >= 0, f"BatteryNonNegative_{i}_{k}")

# Constraint: Electric train's battery is full at the start of the day
for i in range(1, total_trains + 1):
    model.addConstr(B[i, 0] == 8 * E[i], f"BatteryFullStart_{i}")


# Constraint: Battery becomes 8 when charged
for i in range(1, total_trains + 1):
    for n in range(1, total_nodes + 1):
        for k in range(0, total_travel_times[i] + 1):
            model.addConstr(B[i, k] >= 8 * Z[i, n, k], f"BatteryCharged_{i}_{k}")


# Constraint: Battery decreases by 1 each hour when not charged and is an electric train
for i in range(1, total_trains + 1):
    for k in range(1, total_travel_times[i] + 1):
        model.addConstr(
            B[i, k] == B[i, k - 1] - E[i] + quicksum(Z[i, n, k] for n in range(1, total_nodes + 1)) * E[i],
            
            f"BatteryDecrease_{i}_{k}"
        )


model.update()
##model.computeIIS()
model.optimize()

charging_stations = {node: 0 for node in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']}

for i in range(1, total_trains + 1):
    for k in range(1, total_travel_times[i] + 1):
        if B[i, k].X > B[i, k - 1].X:
            # Train i is charged at time k
            if (isinstance(find_current_node(i,k), str)):
                current_node = find_current_node(i,k)  # Get the node location of train i at time k
                charging_stations[current_node] += 1

# Output the number of charging stations at each node
for node, count in charging_stations.items():
    print(f"Node {node} has {count} charging stations.")

if model.status == GRB.Status.OPTIMAL:
    print(f"Optimal value: {model.objVal}")
    # Print decision variable values
else:
    print("No optimal solution found.")

# Displaying train types (Electric or Diesel)
for i in range(1, total_trains + 1):
    train_type = "Electric" if E[i].X > 0.5 else "Diesel"
    print(f"Train {i} is {train_type}")

# Displaying the number of charging stations at each node
for n in range(1, total_nodes + 1):
    print(f"Number of charging stations at Node {n}: {ElectricStation_Node[n].X}")
    
# Displaying the number of charging and fuel stations at each depot
for d in range(1, total_depots + 1):
    print(f"Number of electric charging stations at Depot {d}: {ElectricStation_Depot[d].X}")
    print(f"Number of fuel stations at Depot {d}: {FuelStation_Depot[d].X}")
'''