'''
import cplex
from cplex.exceptions import CplexError

# Sample Data (You would replace this with actual data from your "distances.txt" and "depot node distances.txt")
depot_distances = {
    'X': {'A': 1, 'B': 1 , 'C':1, 'D': 2, 'E': 3, 'F': 2, 'G': 1, 'H': 1},
    'Y': {'A': 3, 'B': 2, 'C': 1, 'D': 1, 'E': 1, 'F': 1, 'G': 1, 'H': 2}
}

train_paths = {
    1: ['A', 'C', 'H', 'B'],  # Train 1 path: A-C-H-B
    2: ['B', 'G', 'A'],      # Train 2 path: B-G-A
    3: ['C', 'G', 'D'],      # Train 3 path: C-G-D
    4: ['D', 'F', 'E', 'G', 'C'], # Train 4 path: D-F-E-G-C
    5: ['E', 'F', 'C'],      # Train 5 path: E-F-C
    6: ['H', 'G', 'F'],      # Train 6 path: H-G-F
    7: ['A', 'H', 'G', 'E'], # Train 7 path: A-H-G-E
    8: ['B', 'H', 'C'],      # Train 8 path: B-H-C
    9: ['C', 'E', 'H'],      # Train 9 path: C-E-H
    10: ['F', 'G', 'E', 'A', 'B', 'C', 'D', 'E'], # Train 10 path: F-G-E-A-B-C-D-E
    11: ['A', 'B', 'C'],     # Train 11 path: A-B-C
    12: ['A', 'F'],          # Train 12 path: A-F
    13: ['B', 'F', 'D'],     # Train 13 path: B-F-D
    14: ['G', 'C', 'E'],     # Train 14 path: G-C-E
    15: ['B', 'D', 'G'],     # Train 15 path: B-D-G
}

num_trains = 15
stations = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
depots = ['X', 'Y']

# Initialize the CPLEX problem
prob = cplex.Cplex()
prob.set_problem_type(cplex.Cplex.problem_type.LP)

# Objective is to minimize distance
prob.objective.set_sense(prob.objective.sense.minimize)

# Decision Variables: x_{train}_{depot}
var_names = ["x{}_{}".format(train, depot) for train in range(1, num_trains + 1) for depot in depots]
prob.variables.add(names=var_names, types=[prob.variables.type.binary] * len(var_names))

# Objective Function: Sum of distances for start and end nodes of each train path to depots
objective = []
for train, path in train_paths.items():
    start_station = path[0]  # This should be a string like 'A'
    end_station = path[-1]  # This should also be a string like 'B'
    print(start_station)
    print(end_station)
    for depot in depots:
        var_name = f"x{train}_{depot}"
        # The following line should not throw KeyError if start_station and end_station are correct
        distance = depot_distances[depot][start_station] + depot_distances[depot][end_station]
        objective.append((var_name, distance))
prob.objective.set_linear(objective)

# Constraints

# Each train is assigned to exactly one depot
for train in range(1, num_trains + 1):
    constraint = [["x{}_{}".format(train, depot) for depot in depots], [1] * len(depots)]
    prob.linear_constraints.add(lin_expr=[constraint], senses=["E"], rhs=[1])

# Each depot has at least 5 trains
for depot in depots:
    constraint = [["x{}_{}".format(train, depot) for train in range(1, num_trains + 1)], [1] * num_trains]
    prob.linear_constraints.add(lin_expr=[constraint], senses=["G"], rhs=[5])

# No more than 3 trains start from the same station for each depot
for depot in depots:
    for station in stations:
        constraint_vars = ["x{}_{}".format(train, depot) for train, path in train_paths.items() if path[0] == station]
        constraint_coefs = [1] * len(constraint_vars)
        prob.linear_constraints.add(lin_expr=[[constraint_vars, constraint_coefs]], senses=["L"], rhs=[3])

# Solve the model
try:
    prob.solve()
except CplexError as e:
    print("Cplex Error:", e)

# Output the solution
solution = prob.solution
if solution.is_primal_feasible():
    print("Solution status:", solution.get_status())
    print("Total minimized distance:", solution.get_objective_value())
    for train in range(1, num_trains + 1):
        for depot in depots:
            if solution.get_values("x{}_{}".format(train, depot)) > 0.5:  # Binary variables, so > 0.5 means 1
                print("Train {} is assigned to depot {}".format(train, depot))
else:
    print("No feasible solution found.")
'''