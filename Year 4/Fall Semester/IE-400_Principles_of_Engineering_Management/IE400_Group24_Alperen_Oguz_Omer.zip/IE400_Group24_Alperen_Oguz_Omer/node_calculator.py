'''
# Distance matrix between nodes (A-H)
node_distances = [
    [0.0, 1.0, 2.0, 1.0, 1.0, 2.0, 2.0, 1.0],
    [1.0, 0.0, 1.0, 1.0, 2.0, 3.0, 1.0, 3.0],
    [2.0, 1.0, 0.0, 1.0, 2.0, 2.0, 3.0, 2.0],
    [1.0, 1.0, 1.0, 0.0, 1.0, 2.0, 1.0, 2.0],
    [1.0, 2.0, 2.0, 1.0, 0.0, 1.0, 3.0, 2.0],
    [2.0, 3.0, 2.0, 2.0, 1.0, 0.0, 1.0, 2.0],
    [2.0, 1.0, 3.0, 1.0, 3.0, 1.0, 0.0, 1.0],
    [1.0, 3.0, 2.0, 2.0, 2.0, 2.0, 1.0, 0.0]
]

# Distances from depots to nodes
depot_distances = {
    'X': [1, 1, 1, 2, 3, 2, 1, 1],
    'Y': [3, 2, 1, 1, 1, 1, 1, 2]
}

train_depot_assignment = {
    1: 'X',
    2: 'X',
    3: 'Y',
    4: 'Y',
    5: 'Y',
    6: 'Y',
    7: 'Y',
    8: 'X',
    9: 'X',
    10:'Y',
    11:'X',
    12:'X',
    13:'Y',
    14:'Y',
    15:'X'
}

train_paths = {
    1: ['A', 'C', 'H', 'B'],
    2: ['B', 'G', 'A'],
    3: ['C', 'G', 'D'],
    4: ['D', 'F', 'E', 'G', 'C'],
    5: ['E', 'F', 'C'],
    6: ['H', 'G', 'F'],
    7: ['A', 'H', 'G', 'E'],
    8: ['B', 'H', 'C'],
    9: ['C', 'E', 'H'],
    10: ['F', 'G', 'E', 'A', 'B', 'C', 'D', 'E'],
    11: ['A', 'B', 'C'],
    12: ['A', 'F'],
    13: ['B', 'F', 'D'],
    14: ['G', 'C', 'E'],
    15: ['B', 'D', 'G']
}
node_index = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7}
node_index_opp = {0:'A', 1:'B', 2:'C', 3:'D', 4:'E', 5:'F', 6:'G', 7:'H'}

def find_current_node(train, time):
    path = train_paths[train]
    depot = train_depot_assignment[train]
    num_cycles = {
        1: 2, 2: 4, 3: 3, 4: 1, 5: 4, 6: 4, 7: 2, 8: 3, 9: 3, 10: 1,
        11: 5, 12: 4, 13: 3, 14: 2, 15: 6
    }
    total_time = 0

    current_node_idx = -1
    
    # Time from depot to the first node
    first_node_idx = node_index[path[0]]
    total_time += depot_distances[depot][first_node_idx]
    #print(f"starting at node = {depot}, next node = {node_index_opp[first_node_idx]}, total_time = {total_time}")
    
    if total_time > time:
        return  depot
    
    # Loop through the path for the specified number of cycles
    for cycle in range(num_cycles[train]):
        #print("cycle ", cycle)
        for i in range(len(path)):
            # if the total is higher than our decided time
            if total_time > time:
                #print("asd")
                return node_index[path[i]]

            current_node_idx = node_index[path[i]]
            
            if ( cycle == num_cycles[train] - 1) and ( i == len(path) - 1):
                next_node_idx = depot 
                total_time += depot_distances[next_node_idx][current_node_idx]
                #print(f"current node = {node_index_opp[current_node_idx]}, next node = {next_node_idx}, total_time = {total_time}")
            else:
                next_node_idx = node_index[path[(i + 1) % len(path)]]
                total_time += node_distances[current_node_idx][next_node_idx]
                #print(f"current node = {node_index_opp[current_node_idx]}, next node = {node_index_opp[next_node_idx]}, total_time = {total_time}")
                        
            if total_time > time:
                return node_index_opp[current_node_idx]
            
    # If the total time is still not exceeded, then the train is in the depot
    return depot



def is_train_at_node(train_number, node_alphabet, time):
    # Map node number back to letter using an inverse of the node_index dictionary
    # Use the find_current_node function to get the current node of the train at the given time
    current_node = find_current_node(train_number, time)
    # Check if the current node matches the specified node
    return current_node == node_alphabet

current_node = find_current_node(1, 21)  # Example: Find where train 1 is at time 5
print("Train 1 is at node:", current_node)

print(is_train_at_node(1,'X',21))
'''