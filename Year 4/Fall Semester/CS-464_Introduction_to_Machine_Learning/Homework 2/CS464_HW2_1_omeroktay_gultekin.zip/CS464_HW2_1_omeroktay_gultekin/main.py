import argparse
import subprocess


def run_script(script_path):
    subprocess.run(["python", script_path])

def main():
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--question", help="Question to run, q1, q2 or all if you want to run all questions")
    args = parser.parse_args()

    # question calls
    if args.question == 'q1':
        run_script("q1_script.py")
    elif args.question == 'q2':
        run_script("q2_script.py")
    elif args.question == 'all':
        run_script("q1_script.py")
        run_script("q2_script.py")

main()
