You may wish to directly use the main.py file with the below considerations or use the ipynb files to open it in notebook enviroment. Note that homework is written on vs code so that no drive mounting of the files done, use the ipynb files cautiously. Also, codes looking for data folder to read the files.

Numpy, pandas, sklearn and matplotlib library packages must be installed on coding environment to be able to run the code.

Program Params:
--question: Question to run, values can be q1, q2 or all if you want to run all q1 and q2.

Example executions:
python main.py --question q1
python main.py --question q2
python main.py --question all

