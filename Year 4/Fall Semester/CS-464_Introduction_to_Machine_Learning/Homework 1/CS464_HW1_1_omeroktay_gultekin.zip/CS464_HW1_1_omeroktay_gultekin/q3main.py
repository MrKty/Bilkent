import numpy as np, pandas as pd, matplotlib.pyplot as plt
import time
import argparse

# read the csv files into a pandas dataframe and convert the dataframes to a numpy array
y_train_df = pd.read_csv('y_train.csv', header=None)
y_train = np.array(y_train_df)

y_test_df = pd.read_csv('y_test.csv', header=None)
y_test = np.array(y_test_df)

x_train_df = pd.read_csv('X_train.csv', delimiter=' ')
X_train = np.array(x_train_df)

x_test_df = pd.read_csv('X_test.csv', delimiter=' ')
X_test = np.array(x_test_df)

# Common things methods will use
alpha_value = 1
output_file = open("output.txt", "w")

class_counts_training = {}

for label in y_train:
    if label[0] in class_counts_training:
        class_counts_training[label[0]] += 1
    else:
        class_counts_training[label[0]] = 1

prior_probabilities = {}

for key, value in class_counts_training.items():
    prior_probabilities[key] = value / len(y_train)


def q32():
    log_to_file_and_print()
    log_to_file_and_print('Q32:')
    start = time.time()
    class_word_counts = np.zeros((5, len(x_train_df.columns)), dtype=int)

    for i in range(len(X_train)):
        current_class = y_train[i][0]

        class_word_counts[current_class] += X_train[i]

    class_word_probabilities = np.zeros((5, len(x_train_df.columns)), dtype=float)

    for key in prior_probabilities.keys():
        class_word_probabilities[key] = np.zeros(
            len(x_train_df.columns), dtype=float)    

    # the total number of words class has
    total_words = {}
    for key in prior_probabilities.keys():
        total_words[key] = np.sum(class_word_counts[key])

    for key in prior_probabilities.keys():
        for i in range(class_word_counts[key].shape[0]):
            total_occurance_of_class = total_words[0] + total_words[1] + total_words[2] + total_words[3] + total_words[4]
            feature_prob_given_class = class_word_counts[key][i] / total_occurance_of_class
            class_word_probabilities[key][i] = feature_prob_given_class

    guesses = np.zeros(len(X_test), dtype=int)

    class_word_probabilities_logs = np.zeros((5, len(x_train_df.columns)), dtype=float)

    for key in range(5):
        class_word_probabilities_logs[key] = np.where(class_word_probabilities[key] == 0, -10**12, np.log(class_word_probabilities[key]))
  
    for i in range(len(X_test)):
        X_test[i] = np.where(X_test[i] > 0, 1, 0)
        max_probability = -np.inf
        max_probability_class = 0
        for key in [0, 1, 2, 3, 4]:
            probability = np.log(prior_probabilities[key])
            probability += np.sum(X_test[i] * class_word_probabilities_logs[key])
            if probability > max_probability:
                max_probability = probability
                max_probability_class = key
        guesses[i] = max_probability_class

    correct_guesses = 0
    for i in range(len(y_test)):
        if guesses[i] == y_test[i][0]:
            correct_guesses += 1

    log_to_file_and_print('Correct Guesses: ' + str(correct_guesses))

    log_to_file_and_print('Incorrect Guesses: ' + str(len(y_test) - correct_guesses))

    log_to_file_and_print('Accuracy: ' + str(correct_guesses / len(y_test)))

    confusion_matrix = np.zeros((5, 5), dtype=int)

    for i in range(len(guesses)):
        confusion_matrix[guesses[i]][y_test[i][0]] += 1

    log_to_file_and_print('Confusion Matrix:')
    log_to_file_and_print(confusion_matrix)
    end = time.time()
    log_to_file_and_print('Time Taken: ' + str(end - start))

def q33():
    log_to_file_and_print()
    log_to_file_and_print('Q33:')
    start = time.time()
    class_word_counts = np.zeros((5, len(x_train_df.columns)), dtype=int)

    for i in range(len(X_train)):
        current_class = y_train[i][0]

        class_word_counts[current_class] += X_train[i]

    class_word_probabilities = np.zeros((5, len(x_train_df.columns)), dtype=float)

    for key in prior_probabilities.keys():
        class_word_probabilities[key] = np.zeros(
            len(x_train_df.columns), dtype=float)    

    # the total number of words class has
    total_words = np.zeros(5, dtype=int)
    for key in prior_probabilities.keys():
        total_words[key] = np.sum(class_word_counts[key])

    for key in prior_probabilities.keys():
        for i in range(class_word_counts[key].shape[0]):
            total_occurance_of_class = np.sum(total_words) + alpha_value * 9635
            feature_prob_given_class = (class_word_counts[key][i] + alpha_value) / total_occurance_of_class
            class_word_probabilities[key][i] = feature_prob_given_class

    guesses = np.zeros(len(X_test), dtype=int)
  
    for i in range(len(X_test)):
        X_test[i] = np.where(X_test[i] > 0, 1, 0)
        max_probability = -10**15
        max_probability_class = 0
        for key in [0, 1, 2, 3, 4]:
            probability = np.log(prior_probabilities[key])
            probability += np.sum(X_test[i] * np.log(class_word_probabilities[key]))
            if probability > max_probability:
                max_probability = probability
                max_probability_class = key
        guesses[i] = max_probability_class

    correct_guesses = 0
    for i in range(len(y_test)):
        if guesses[i] == y_test[i][0]:
            correct_guesses += 1

    log_to_file_and_print('Correct Guesses: ' + str(correct_guesses))

    log_to_file_and_print('Incorrect Guesses: ' + str(len(y_test) - correct_guesses))

    log_to_file_and_print('Accuracy: ' + str(correct_guesses / len(y_test)))

    confusion_matrix = np.zeros((5, 5), dtype=int)

    for i in range(len(guesses)):
        confusion_matrix[guesses[i]][y_test[i][0]] += 1

    log_to_file_and_print('Confusion Matrix:')
    log_to_file_and_print(confusion_matrix)
    end = time.time()
    log_to_file_and_print('Time Taken: ' + str(end - start))

def q34():
    log_to_file_and_print()
    log_to_file_and_print('Q34:')
    start = time.time()
    class_word_counts = np.zeros((5, len(x_train_df.columns)), dtype=int)

    for i in range(len(X_train)):
        current_class = y_train[i][0]

        X_train[i] = np.where(X_train[i] > 0, 1, 0)

        class_word_counts[current_class] += X_train[i]

    class_word_probabilities = np.zeros((5, len(x_train_df.columns)), dtype=float)

    for key in prior_probabilities.keys():
        class_word_probabilities[key] = np.zeros(
            len(x_train_df.columns), dtype=float)    

    # find the total number of words class has
    total_words = {}
    for key in prior_probabilities.keys():
        total_words[key] = np.sum(class_word_counts[key])

    for key in prior_probabilities.keys():
        for i in range(class_word_counts[key].shape[0]):
            total_occurance_of_class = class_counts_training[key] + 2 * alpha_value
            feature_prob_given_class = (class_word_counts[key][i] + alpha_value) / total_occurance_of_class
            class_word_probabilities[key][i] = feature_prob_given_class

    # np array to store the guesses for each document
    guesses = np.zeros(len(X_test), dtype=int)
  
    for i in range(len(X_test)):
        X_test[i] = np.where(X_test[i] > 0, 1, 0)
        max_probability = -np.inf
        max_probability_class = 0
        for key in [0, 1, 2, 3, 4]:
            probability = np.log(prior_probabilities[key])
            probability += np.sum(np.log(X_test[i] * class_word_probabilities[key] + (1 - X_test[i]) * (1 - class_word_probabilities[key])))
            if probability > max_probability:
                max_probability = probability
                max_probability_class = key
        guesses[i] = max_probability_class

    correct_guesses = 0
    for i in range(len(y_test)):
        if guesses[i] == y_test[i][0]:
            correct_guesses += 1

    log_to_file_and_print('Correct Guesses: ' + str(correct_guesses))

    log_to_file_and_print('Incorrect Guesses: ' + str(len(y_test) - correct_guesses))

    log_to_file_and_print('Accuracy: ' + str(correct_guesses / len(y_test)))

    confusion_matrix = np.zeros((5, 5), dtype=int)

    for i in range(len(guesses)):
        confusion_matrix[guesses[i]][y_test[i][0]] += 1

    log_to_file_and_print('Confusion Matrix:')
    log_to_file_and_print(confusion_matrix)
    end = time.time()
    log_to_file_and_print('Time Taken: ' + str(end - start))

def q31():
    log_to_file_and_print('Training Class Counts:')
    log_to_file_and_print(class_counts_training)

    class_counts_testing = {}

    for label in y_test:
        if label[0] in class_counts_testing:
            class_counts_testing[label[0]] += 1
        else:
            class_counts_testing[label[0]] = 1

    log_to_file_and_print('Class Counts:')
    log_to_file_and_print(class_counts_testing)

    class_names = {0: 'Business', 1: 'Entertainment', 2: 'Politics', 3: 'Sport', 4: 'Tech'}

    class_counts_testing = {class_names[key]: value for key, value in class_counts_testing.items()}

    class_counts_training = {class_names[key]: value for key, value in class_counts_training.items()}

    plt.pie(class_counts_training.values(), labels=class_counts_training.keys(), autopct='%1.1f%%')
    plt.title('Training Class Counts')
    plt.show()

    plt.pie(class_counts_testing.values(), labels=class_counts_testing.keys(), autopct='%1.1f%%')
    plt.title('Testing Class Counts')
    plt.show()

    log_to_file_and_print('Prior Probabilities:')
    log_to_file_and_print(prior_probabilities)

def q31d():
    # find the indices of alien and thunder in header
    alien_index = x_train_df.columns.get_loc('alien')
    thunder_index = x_train_df.columns.get_loc('thunder')

    log_to_file_and_print('Alien Index: ' + str(alien_index))
    log_to_file_and_print('Thunder Index: ' + str(thunder_index))

    # find the row indexes that alien_index and thunder_index are not 0
    alien_row_indexes = np.where(X_train[:, alien_index] != 0) 
    thunder_row_indexes = np.where(X_train[:, thunder_index] != 0)

    log_to_file_and_print('Alien Row Indexes: ' + str(alien_row_indexes))
    log_to_file_and_print('Thunder Row Indexes: ' + str(thunder_row_indexes))

    alien_y_train = y_train[alien_row_indexes]
    thunder_y_train = y_train[thunder_row_indexes]

    log_to_file_and_print('Alien Y Train: ' + str(alien_y_train))
    log_to_file_and_print('Thunder Y Train: ' + str(thunder_y_train))

    alien_counter = 0
    for i in range(0, len(alien_y_train)):
        if alien_y_train[i][0] == 4:
            log_to_file_and_print('Row Index: ' + str(alien_row_indexes[0][i]))
            log_to_file_and_print(X_train[alien_row_indexes[0][i]][alien_index])
            alien_counter += X_train[alien_row_indexes[0][i]][alien_index]

    thunder_counter = 0
    for i in range(len(thunder_y_train)):
        if thunder_y_train[i][0] == 4:
            log_to_file_and_print(X_train[thunder_row_indexes[0][i]][thunder_index])
            thunder_counter += X_train[thunder_row_indexes[0][i]][thunder_index]

    log_to_file_and_print('Alien Counter: ' + str(alien_counter))
    log_to_file_and_print('Thunder Counter: ' + str(thunder_counter))

    # find total number of words in class 4
    total_words = 0
    for i in range(len(y_train)):
        if y_train[i][0] == 4:
            total_words += np.sum(X_train[i])

    log_to_file_and_print('Total Words: ' + str(total_words))

    log_to_file_and_print('ln(P(alien | Y = Tech))')
    log_to_file_and_print(np.log(alien_counter / total_words))

    log_to_file_and_print('ln(P(thunder | Y = Tech))')
    log_to_file_and_print(np.log(thunder_counter / total_words))

np.seterr(divide = 'ignore') 

def log_to_file_and_print(text=""):
    output_file.write(str(text) + '\n')
    print(text)


def main():
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--testPath", help="Path to the test data, if you want to run with validation data, do not include this argument")
    parser.add_argument("--method", help="Method to use, q31, q31d, q32, q33, q34 and all if you want to run all q32 to q34")
    parser.add_argument("--alpha", help="Alpha value to use for q33 and q34")
    args = parser.parse_args()

    if args.testPath:
        y_test_df = pd.read_csv(args.testPath, header=None)
        y_test = np.array(y_test_df)
    else:
        print('no testPath, falling back to the validation data')
    
    if args.method:
        print('which one', args.method)
    else:
        print('no method, falling back to all')
        args.method = 'all'
    
    if args.alpha:
        alpha_value = int(args.alpha)

    # method calls
    if args.method == 'q31':
        q31()
    elif args.method == 'q31d':
        q31d()
    elif args.method == 'q32':
        q32()
    elif args.method == 'q33':
        q33()
    elif args.method == 'q34':
        q34()
    elif args.method == 'all':
        q32()
        q33()
        q34()

main()
