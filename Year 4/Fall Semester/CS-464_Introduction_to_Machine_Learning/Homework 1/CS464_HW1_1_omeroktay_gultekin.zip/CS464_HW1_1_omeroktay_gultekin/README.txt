Numpy, pandas, and matplotlib library packages must be installed on coding environment to be able to run the code.

Program Params:
--testPath: Path to the test data, if you want to run with validation data, do not include this argument (default is validationPath defined in code)
--method: Method to use, values can be q31, q31d, q32, q33, q34 or all if you want to run all q32 to q34 (default is all, if not defined)
--alpha: Alpha value to use for q33 and q34 (default is 1, if not defined)

Example executions:
python q3main.py --testPath y_train.csv --method q34
python q3main.py --testPath y_train.csv --method q33 -alpha 2
python q3main.py --method all
python q3main.py

Output:
output of the methods goes into terminal as well as output.txt file.
The file will be overriden when program is run again.
